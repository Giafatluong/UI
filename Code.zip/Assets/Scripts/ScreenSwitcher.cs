using UnityEngine;

[ExecuteAlways]
public class ScreenSwitcher : MonoBehaviour
{
    [Header("Screens")]
    public GameObject screen1_Main;
    public GameObject screen2_BuyGear;

    [Header("Display Mode")]
    [Tooltip("0 = Screen 1 (Main), 1 = Screen 2 (Buy Gear), 2 = Side by Side")]
    [Range(0, 2)]
    public int currentMode = 0;

    private void Update()
    {
        if (Application.isPlaying)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1)) SetMode(0);
            if (Input.GetKeyDown(KeyCode.Alpha2)) SetMode(1);
            if (Input.GetKeyDown(KeyCode.Alpha3)) SetMode(2);
        }
    }

    private void OnValidate()
    {
        ApplyMode();
    }

    [ContextMenu("Show Screen 1 (Main)")]
    public void ShowScreen1()
    {
        SetMode(0);
    }

    [ContextMenu("Show Screen 2 (Buy Gear)")]
    public void ShowScreen2()
    {
        SetMode(1);
    }

    [ContextMenu("Show Side by Side")]
    public void ShowSideBySide()
    {
        SetMode(2);
    }

    public void SetMode(int mode)
    {
        currentMode = mode;
        ApplyMode();
    }

    private void ApplyMode()
    {
        if (screen1_Main == null || screen2_BuyGear == null) return;

        var rt1 = screen1_Main.GetComponent<RectTransform>();
        var rt2 = screen2_BuyGear.GetComponent<RectTransform>();

        if (currentMode == 0) // Screen 1 only
        {
            screen1_Main.SetActive(true);
            screen2_BuyGear.SetActive(false);
            if (rt1 != null) rt1.anchoredPosition = Vector2.zero;
        }
        else if (currentMode == 1) // Screen 2 only
        {
            screen1_Main.SetActive(false);
            screen2_BuyGear.SetActive(true);
            if (rt2 != null) rt2.anchoredPosition = Vector2.zero;
        }
        else if (currentMode == 2) // Side by Side
        {
            screen1_Main.SetActive(true);
            screen2_BuyGear.SetActive(true);
            if (rt1 != null) rt1.anchoredPosition = new Vector2(-210, 0);
            if (rt2 != null) rt2.anchoredPosition = new Vector2(210, 0);
        }
    }
}
