using UnityEngine;
using UnityEditor;
using UnityEngine.UI;
using UnityEditor.SceneManagement;
using System.IO;

[InitializeOnLoad]
public class InGameUIBuilder
{
    private const string SCENE_PATH = "Assets/Scenes/InGameScreens.unity";

    [InitializeOnLoadMethod]
    private static void AutoRunOnCompile()
    {
        EditorApplication.delayCall += () =>
        {
            BuildScreens();
        };
    }

    [MenuItem("Tools/Open InGame UI Scene")]
    public static void OpenInGameScene()
    {
        EditorSceneManager.OpenScene(SCENE_PATH);
    }

    [MenuItem("Tools/Build InGame UI Screens")]
    public static void BuildScreens()
    {
        Debug.Log("[InGameUIBuilder] Building InGame Screens from UI Assets...");

        // Ensure directory exists
        string sceneDir = Path.GetDirectoryName(SCENE_PATH);
        if (!Directory.Exists(sceneDir))
        {
            Directory.CreateDirectory(sceneDir);
        }

        // Create new scene
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // 1. Create Main Camera
        var cameraGo = new GameObject("Main Camera");
        var cam = cameraGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.52f, 0.76f, 0.97f); // Sky blue #85C2F7
        cam.orthographic = true;
        cam.orthographicSize = 5f;
        cam.nearClipPlane = 0.3f;
        cam.farClipPlane = 1000f;
        cameraGo.AddComponent<AudioListener>();

        // 2. Create Event System
        var eventSystemGo = new GameObject("EventSystem");
        eventSystemGo.AddComponent<UnityEngine.EventSystems.EventSystem>();
        eventSystemGo.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();

        // 3. Create Canvas
        var canvasGo = new GameObject("Canvas");
        var canvas = canvasGo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasGo.AddComponent<GraphicRaycaster>();

        var scaler = canvasGo.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(402, 874);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        // Add switcher component
        var switcher = canvasGo.AddComponent<ScreenSwitcher>();

        // Default built-in font for Unity 2022.3
        Font font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        // 4. Create Screen 1: Main Gameplay
        GameObject screen1 = CreateScreen("Screen_1_Main", canvasGo.transform, false, font);

        // 5. Create Screen 2: Buy Gear
        GameObject screen2 = CreateScreen("Screen_2_BuyGear", canvasGo.transform, true, font);
        screen2.SetActive(false); // Initially screen 1 is active

        switcher.screen1_Main = screen1;
        switcher.screen2_BuyGear = screen2;
        switcher.currentMode = 0;

        // 6. Create Floating Switcher Buttons for Game View
        CreateToggleHUD(canvasGo.transform, switcher, font);

        // Save Scene
        EditorSceneManager.SaveScene(scene, SCENE_PATH);
        Debug.Log("[InGameUIBuilder] Scene created and saved successfully at: " + SCENE_PATH);
    }

    private static GameObject CreateScreen(string screenName, Transform canvasTransform, bool isBuyGearScreen, Font font)
    {
        var screenGo = CreateRect(screenName, canvasTransform, Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);

        // === 1. ENVIRONMENT / BACKGROUND ===
        var bgContainer = CreateRect("Environment", screenGo.transform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, 0), new Vector2(402, 450));

        // Sky & mountains
        CreateImage("Env_Background", bgContainer.transform, GetSprite("environment background"), new Vector2(0, -180), new Vector2(402, 380), preserveAspect: false);

        // Water surface
        CreateImage("Env_Water", bgContainer.transform, GetSprite("envi 1_mainwater"), new Vector2(0, -320), new Vector2(402, 260), preserveAspect: false);

        // === 2. BOAT & CREW (Right Side) ===
        var boatContainer = CreateRect("Boat_Group", screenGo.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(115, 145), new Vector2(160, 130));

        // Boat Body
        CreateImage("Boat_Body", boatContainer.transform, GetSprite("boat"), new Vector2(0, 0), new Vector2(145, 110));
        CreateImage("Boat_Wheel", boatContainer.transform, GetSprite("wheel"), new Vector2(-28, -25), new Vector2(45, 45));
        CreateImage("Boat_Sail", boatContainer.transform, GetSprite("boat sail"), new Vector2(42, 45), new Vector2(50, 65));

        // Characters on Boat
        CreateImage("Char_Nerd", boatContainer.transform, GetSprite("char nerd"), new Vector2(-25, 20), new Vector2(30, 38));
        CreateImage("Char_Tomboy", boatContainer.transform, GetSprite("char tomboy"), new Vector2(20, 14), new Vector2(32, 38));
        CreateImage("Char_Emo", boatContainer.transform, GetSprite("char emo"), new Vector2(8, 42), new Vector2(28, 36));
        CreateImage("Char_Dreadlock", boatContainer.transform, GetSprite("char dreadlock"), new Vector2(38, 38), new Vector2(28, 36));

        // Boat Health Bar & Gem
        var boatStatus = CreateRect("Boat_Status", screenGo.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(118, 225), new Vector2(60, 40));
        CreateImage("Boat_HP_Bg", boatStatus.transform, GetSprite("slider gameplay_background"), new Vector2(0, -2), new Vector2(40, 8), preserveAspect: false);
        CreateImage("Boat_HP_Fill", boatStatus.transform, GetSprite("slider gameplay_fill_green"), new Vector2(0, -2), new Vector2(38, 6), preserveAspect: false);
        CreateText("Boat_HP_Text", boatStatus.transform, "120", new Vector2(0, 7), new Vector2(40, 14), 10, Color.black, font, TextAnchor.MiddleCenter, FontStyle.Bold);

        // Gem above HP
        CreateImage("Gem_Icon", boatStatus.transform, GetSprite("slider gameplay_fill_cyan"), new Vector2(-10, 20), new Vector2(8, 8));
        CreateText("Gem_Text", boatStatus.transform, "89", new Vector2(6, 20), new Vector2(30, 14), 11, Color.cyan, font, TextAnchor.MiddleLeft, FontStyle.Bold);

        // Skull badge below HP
        CreateImage("Skull_Badge", boatStatus.transform, GetSprite("icon_skull"), new Vector2(-6, -15), new Vector2(12, 12));
        CreateText("Skull_Text", boatStatus.transform, "2", new Vector2(6, -15), new Vector2(20, 14), 10, Color.green, font, TextAnchor.MiddleLeft, FontStyle.Bold);

        // Right edge status tags
        CreateSideTags(screenGo.transform, font);

        // === 3. MOBS & BOSS IN WATER (Left Side) ===
        var mobContainer = CreateRect("Mobs_Group", screenGo.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);

        // Giant Boss Monster
        CreateImage("Boss_Monster", mobContainer.transform, GetSprite("Boss1"), new Vector2(-128, 145), new Vector2(145, 125));
        CreateImage("Boss_HP_Bg", mobContainer.transform, GetSprite("slider gameplay_background"), new Vector2(-135, 222), new Vector2(105, 9), preserveAspect: false);
        CreateImage("Boss_HP_Fill", mobContainer.transform, GetSprite("slider gameplay_fill_red"), new Vector2(-147, 222), new Vector2(80, 7), preserveAspect: false);

        // Pink Flying Mob 1
        CreateImage("Mob_Flying_1", mobContainer.transform, GetSprite("Mob1_Flying"), new Vector2(-105, 260), new Vector2(36, 30));

        // Pink Flying Mob 2 + HP
        CreateImage("Mob_Flying_2", mobContainer.transform, GetSprite("Mob1_Flying"), new Vector2(-30, 245), new Vector2(36, 30));
        CreateImage("Mob2_HP_Bg", mobContainer.transform, GetSprite("slider gameplay_background"), new Vector2(-30, 264), new Vector2(26, 6), preserveAspect: false);
        CreateImage("Mob2_HP_Fill", mobContainer.transform, GetSprite("slider gameplay_fill_red"), new Vector2(-30, 264), new Vector2(24, 4), preserveAspect: false);

        // Swimming Mob 1 (Fish)
        CreateImage("Mob_Fish_1", mobContainer.transform, GetSprite("Mob1_Fast"), new Vector2(-65, 190), new Vector2(32, 28));

        // Tentacle 1 + HP
        CreateImage("Mob_Tentacle_1", mobContainer.transform, GetSprite("tail"), new Vector2(-18, 170), new Vector2(28, 26));
        CreateImage("Tentacle1_HP", mobContainer.transform, GetSprite("slider gameplay_fill_red"), new Vector2(-18, 186), new Vector2(26, 5), preserveAspect: false);

        // Swimming Mob 2 + HP
        CreateImage("Mob_Fish_2", mobContainer.transform, GetSprite("Mob1_Melee"), new Vector2(2, 155), new Vector2(30, 26));
        CreateImage("Fish2_HP", mobContainer.transform, GetSprite("slider gameplay_fill_red"), new Vector2(2, 171), new Vector2(26, 5), preserveAspect: false);

        // Row of 3 Tentacles rising from water
        CreateImage("Tentacle_Row_1", mobContainer.transform, GetSprite("tail"), new Vector2(-165, 60), new Vector2(22, 26));
        CreateImage("Tentacle_Row_2", mobContainer.transform, GetSprite("tail"), new Vector2(-120, 60), new Vector2(22, 26));
        CreateImage("Tentacle_Row_3", mobContainer.transform, GetSprite("tail"), new Vector2(-75, 60), new Vector2(22, 26));

        // Shark Mob
        CreateImage("Mob_Shark", mobContainer.transform, GetSprite("Mob1_Tank"), new Vector2(-5, 60), new Vector2(44, 30));

        // Lower fish mob
        CreateImage("Mob_Fish_Lower", mobContainer.transform, GetSprite("Mob1_Fast"), new Vector2(-140, 10), new Vector2(30, 26));

        // === 4. TOP BAR HEADER ===
        var topBar = CreateRect("TopBar", screenGo.transform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -10), new Vector2(402, 120));

        // Settings Button (Top Left)
        CreateImage("Btn_Settings", topBar.transform, GetSprite("button_main_gray"), new Vector2(-175, -28), new Vector2(32, 32));

        // Level 12 Title
        CreateText("Text_Level", topBar.transform, "Level 12", new Vector2(0, -14), new Vector2(160, 24), 18, new Color(0.18f, 0.25f, 0.35f), font, TextAnchor.MiddleCenter, FontStyle.Bold);

        // Progress Bar
        CreateImage("Slider_Bg", topBar.transform, GetSprite("slider gameplay_background"), new Vector2(0, -38), new Vector2(275, 14), preserveAspect: false);
        CreateImage("Slider_Fill", topBar.transform, GetSprite("slider gameplay_fill_cyan"), new Vector2(-80, -38), new Vector2(115, 10), preserveAspect: false);

        // Skull markers on progress bar
        CreateImage("Skull_1", topBar.transform, GetSprite("icon_skull"), new Vector2(-80, -28), new Vector2(14, 14));
        CreateImage("Skull_2", topBar.transform, GetSprite("icon_skull"), new Vector2(-25, -28), new Vector2(14, 14));
        CreateImage("Skull_3", topBar.transform, GetSprite("icon_skull"), new Vector2(90, -28), new Vector2(14, 14));
        CreateImage("Flag_Finish", topBar.transform, GetSprite("icon_flag finish"), new Vector2(138, -28), new Vector2(16, 16));

        // Distance Pointer Pin (123m)
        CreateImage("Pin_Pointer", topBar.transform, GetSprite("distance pointer"), new Vector2(-36, -50), new Vector2(46, 18));
        CreateText("Text_Distance", topBar.transform, "123m", new Vector2(-36, -50), new Vector2(46, 18), 10, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);

        // Close Button X (Top Right)
        CreateImage("Btn_Close", topBar.transform, GetSprite("button_big_yellow"), new Vector2(175, -28), new Vector2(32, 32));
        CreateText("Close_X", topBar.transform, "X", new Vector2(175, -28), new Vector2(32, 32), 16, new Color(0.25f, 0.45f, 0.1f), font, TextAnchor.MiddleCenter, FontStyle.Bold);

        // Speed Button (x2)
        CreateImage("Btn_Speed", topBar.transform, GetSprite("button_xspeed"), new Vector2(175, -78), new Vector2(34, 34));

        // Sun Energy Tag (Top Left)
        CreateImage("Sun_Tag_Bg", topBar.transform, GetSprite("tag_price"), new Vector2(-148, -78), new Vector2(80, 32), preserveAspect: false);
        CreateImage("Sun_Icon", topBar.transform, GetSprite("icon_sun"), new Vector2(-168, -78), new Vector2(30, 30));
        CreateText("Sun_Text", topBar.transform, "165", new Vector2(-135, -78), new Vector2(45, 20), 16, new Color(1f, 0.88f, 0.2f), font, TextAnchor.MiddleCenter, FontStyle.Bold);

        // Difficulty "Hard" Tag
        CreateImage("Hard_Tag", topBar.transform, GetSprite("Hard"), new Vector2(0, -78), new Vector2(54, 20));

        // Screen 2 Specific: Sun 50 Button (Top Right)
        if (isBuyGearScreen)
        {
            var sun50Btn = CreateRect("Btn_Sun50_Ad", topBar.transform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(130, -135), new Vector2(120, 46));
            CreateImage("Sun50_Bg", sun50Btn.transform, GetSprite("button_big_yellow"), Vector2.zero, new Vector2(120, 46), preserveAspect: false);
            CreateImage("Sun50_Icon", sun50Btn.transform, GetSprite("icon_sun"), new Vector2(-28, 0), new Vector2(30, 30));
            CreateText("Sun50_Text", sun50Btn.transform, "50", new Vector2(10, 0), new Vector2(40, 24), 22, new Color(0.18f, 0.25f, 0.35f), font, TextAnchor.MiddleCenter, FontStyle.Bold);
            CreateImage("Sun50_AdBadge", sun50Btn.transform, GetSprite("icon video ad"), new Vector2(46, 15), new Vector2(22, 20));
        }

        // === 5. THE TEAL IN-GAME BOARD ===
        var boardContainer = CreateRect("Board_Teal_Panel", screenGo.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-34, -170), new Vector2(310, 355));
        CreateImage("Panel_Teal_Bg", boardContainer.transform, GetSprite("panel_teal"), Vector2.zero, new Vector2(310, 355), preserveAspect: false);

        // Header Stat Banners inside Board
        CreateBoardHeader(boardContainer.transform, font);

        // Row of 6 Active Gear Slots
        CreateActiveSlots(boardContainer.transform, font);

        // 4x6 Grid of Gears and Lotus Pads
        CreateBoardGrid(boardContainer.transform, font);

        // === 6. RIGHT SIDE BOOSTERS (Screen 1 only, or background on Screen 2) ===
        CreateRightBoosters(screenGo.transform, font);

        // === 7. SCREEN 2 SPECIFIC: BUY GEAR OVERLAY ===
        if (isBuyGearScreen)
        {
            CreateBuyGearOverlay(screenGo.transform, font);
        }

        return screenGo;
    }

    private static void CreateSideTags(Transform parent, Font font)
    {
        var tagsContainer = CreateRect("Side_Tags_Stack", parent, new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(-15, 80), new Vector2(35, 120));

        // Orange 2
        CreateImage("Tag_1_Bg", tagsContainer.transform, GetSprite("tag_price"), new Vector2(0, 45), new Vector2(38, 22), preserveAspect: false);
        CreateImage("Tag_1_Icon", tagsContainer.transform, GetSprite("Gun_pumpkin"), new Vector2(-8, 45), new Vector2(14, 14));
        CreateText("Tag_1_Txt", tagsContainer.transform, "2", new Vector2(6, 45), new Vector2(16, 14), 10, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);

        // Red 0
        CreateImage("Tag_2_Bg", tagsContainer.transform, GetSprite("tag_price"), new Vector2(0, 15), new Vector2(38, 22), preserveAspect: false);
        CreateImage("Tag_2_Icon", tagsContainer.transform, GetSprite("icon_status_burn"), new Vector2(-8, 15), new Vector2(14, 14));
        CreateText("Tag_2_Txt", tagsContainer.transform, "0", new Vector2(6, 15), new Vector2(16, 14), 10, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);

        // Purple 5
        CreateImage("Tag_3_Bg", tagsContainer.transform, GetSprite("tag_price"), new Vector2(0, -15), new Vector2(38, 22), preserveAspect: false);
        CreateImage("Tag_3_Icon", tagsContainer.transform, GetSprite("dot_red"), new Vector2(-8, -15), new Vector2(14, 14));
        CreateText("Tag_3_Txt", tagsContainer.transform, "5", new Vector2(6, -15), new Vector2(16, 14), 10, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);

        // Green 13
        CreateImage("Tag_4_Bg", tagsContainer.transform, GetSprite("tag_price"), new Vector2(0, -45), new Vector2(38, 22), preserveAspect: false);
        CreateImage("Tag_4_Icon", tagsContainer.transform, GetSprite("dot_green"), new Vector2(-8, -45), new Vector2(14, 14));
        CreateText("Tag_4_Txt", tagsContainer.transform, "13", new Vector2(6, -45), new Vector2(16, 14), 10, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
    }

    private static void CreateBoardHeader(Transform boardParent, Font font)
    {
        var headerGroup = CreateRect("Board_Header", boardParent, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -26), new Vector2(290, 30));

        // Red Speed Banner
        var speedBanner = CreateRect("Banner_Speed", headerGroup.transform, new Vector2(0, 0.5f), new Vector2(0, 0.5f), new Vector2(0, 0.5f), new Vector2(70, 0), new Vector2(135, 26));
        CreateImage("Speed_Bg", speedBanner.transform, GetSprite("button_big_red"), Vector2.zero, new Vector2(135, 26), preserveAspect: false);
        CreateImage("Speed_Icon", speedBanner.transform, GetSprite("icon_move speed"), new Vector2(-46, 0), new Vector2(18, 18));
        CreateText("Speed_Text", speedBanner.transform, "52.3mph", new Vector2(0, 0), new Vector2(70, 20), 12, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        CreateImage("Speed_Arrow", speedBanner.transform, GetSprite("arrow up"), new Vector2(46, 0), new Vector2(14, 14));

        // Green Attack Banner
        var attackBanner = CreateRect("Banner_Attack", headerGroup.transform, new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(-70, 0), new Vector2(135, 26));
        CreateImage("Attack_Bg", attackBanner.transform, GetSprite("button_big_green"), Vector2.zero, new Vector2(135, 26), preserveAspect: false);
        CreateImage("Attack_Icon", attackBanner.transform, GetSprite("icon_fire rate"), new Vector2(-46, 0), new Vector2(18, 18));
        CreateText("Attack_Text", attackBanner.transform, "73.3", new Vector2(0, 0), new Vector2(60, 20), 12, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        CreateImage("Attack_Arrow", attackBanner.transform, GetSprite("arrow up"), new Vector2(46, 0), new Vector2(14, 14));
    }

    private static void CreateActiveSlots(Transform boardParent, Font font)
    {
        var slotsGroup = CreateRect("Active_Gear_Slots", boardParent, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -78), new Vector2(290, 70));

        float startX = -120f;
        float spacing = 48f;

        // Slot 1: Rotor Gear
        CreateSingleSlot(slotsGroup.transform, "Slot_1", startX + 0 * spacing, "Slot gear - Active", "Gear Rotor", "0.24/s", null, "Flower - Mechanic", font);

        // Slot 2: Gun Pea (+1)
        CreateSingleSlot(slotsGroup.transform, "Slot_2", startX + 1 * spacing, "Slot gear - Active", "Gun_pea", "1.17/s", "+1", "Flower - Mechanic", font);

        // Slot 3: Gun Chili (+2)
        CreateSingleSlot(slotsGroup.transform, "Slot_3", startX + 2 * spacing, "Slot gear - Active", "Gun_chili", null, "+2", "Flower - BUFF", font);

        // Slot 4: Empty
        CreateSingleSlot(slotsGroup.transform, "Slot_4", startX + 3 * spacing, "Slot gear - Empty", null, null, null, null, font);

        // Slot 5: Empty
        CreateSingleSlot(slotsGroup.transform, "Slot_5", startX + 4 * spacing, "Slot gear - Empty", null, null, null, null, font);

        // Slot 6: Sail
        CreateSingleSlot(slotsGroup.transform, "Slot_6", startX + 5 * spacing, "Slot gear - Active", "sail", null, null, "Flower - BUFF", font);
    }

    private static void CreateSingleSlot(Transform parent, string name, float xPos, string slotBg, string itemSprite, string subText, string badgeText, string flowerSprite, Font font)
    {
        var slot = CreateRect(name, parent, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(xPos, 5), new Vector2(44, 62));
        CreateImage("Bg", slot.transform, GetSprite(slotBg), Vector2.zero, new Vector2(44, 62), preserveAspect: false);

        if (!string.IsNullOrEmpty(itemSprite))
        {
            CreateImage("Item", slot.transform, GetSprite(itemSprite), new Vector2(0, 4), new Vector2(34, 34));
        }

        if (!string.IsNullOrEmpty(subText))
        {
            CreateImage("Sub_Bg", slot.transform, GetSprite("tag_price"), new Vector2(0, -18), new Vector2(34, 14), preserveAspect: false);
            CreateText("Sub_Text", slot.transform, subText, new Vector2(0, -18), new Vector2(34, 12), 9, Color.black, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        }

        if (!string.IsNullOrEmpty(badgeText))
        {
            CreateImage("Badge_Bg", slot.transform, GetSprite("dot_green"), new Vector2(14, 24), new Vector2(18, 16));
            CreateText("Badge_Text", slot.transform, badgeText, new Vector2(14, 24), new Vector2(18, 14), 9, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        }

        if (!string.IsNullOrEmpty(flowerSprite))
        {
            CreateImage("Flower_Deco", slot.transform, GetSprite(flowerSprite), new Vector2(0, -32), new Vector2(24, 24));
        }
    }

    private static void CreateBoardGrid(Transform boardParent, Font font)
    {
        var grid = CreateRect("Grid_Cells", boardParent, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, -68), new Vector2(290, 210));

        // 4 rows x 6 columns
        string[,] layout = new string[4, 6]
        {
            { "Gear 2", "Gear 8", "pad", "Gear_spider", "Flower - BUFF", "pad" },
            { "Gear 4", "wheel", "Gear 1", "Gear 4", "Gear 1", "pad" },
            { "Flower Firepower", "pad", "pad", "Gear_frozen", "Gear_ad", "pad" },
            { "Flower - Mechanic", "light aura", "Flower - BUFF", "pad", "Stone phase 1", "pad" }
        };

        float startX = -120f;
        float spacingX = 48f;
        float startY = 75f;
        float spacingY = 50f;

        for (int r = 0; r < 4; r++)
        {
            for (int c = 0; c < 6; c++)
            {
                string assetName = layout[r, c];
                float x = startX + c * spacingX;
                float y = startY - r * spacingY;

                var cell = CreateRect($"Cell_{r}_{c}", grid.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(x, y), new Vector2(46, 46));

                // Lily pad under every cell
                CreateImage("Pad_Under", cell.transform, GetSprite("pad"), Vector2.zero, new Vector2(44, 44));

                // Item on pad
                if (assetName != "pad")
                {
                    var itemImg = CreateImage(assetName, cell.transform, GetSprite(assetName), Vector2.zero, new Vector2(40, 40));

                    // Special overlay for light aura (x1.5 text)
                    if (assetName == "light aura")
                    {
                        CreateText("Aura_Text", cell.transform, "x1.5", Vector2.zero, new Vector2(40, 40), 12, Color.cyan, font, TextAnchor.MiddleCenter, FontStyle.Bold);
                    }
                }
            }
        }
    }

    private static void CreateRightBoosters(Transform parent, Font font)
    {
        var boosterCol = CreateRect("Right_Boosters_Col", parent, new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(-26, -170), new Vector2(50, 240));

        float startY = 90f;
        float spacing = 60f;

        for (int i = 0; i < 4; i++)
        {
            var btn = CreateRect($"Booster_Btn_{i + 1}", boosterCol.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0, startY - i * spacing), new Vector2(48, 52));
            CreateImage("Booster_Bg", btn.transform, GetSprite("button_booster"), Vector2.zero, new Vector2(48, 52), preserveAspect: false);

            if (i == 0)
            {
                CreateImage("Heart_Boom", btn.transform, GetSprite("Heart Boom"), new Vector2(0, 2), new Vector2(32, 32));
            }

            // Green badge "3" at bottom right
            CreateImage("Badge", btn.transform, GetSprite("dot_green"), new Vector2(14, -14), new Vector2(20, 18));
            CreateText("Badge_3", btn.transform, "3", new Vector2(14, -14), new Vector2(18, 14), 10, Color.black, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        }
    }

    private static void CreateBuyGearOverlay(Transform parent, Font font)
    {
        var buyBar = CreateRect("Buy_Gear_Panel", parent, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0, 130), new Vector2(402, 260));

        // Purple bottom bar background
        CreateImage("Bar_Bottom_Bg", buyBar.transform, GetSprite("bar bottom buy gear"), Vector2.zero, new Vector2(402, 260), preserveAspect: false);

        // 4 Buy Cards
        float[] cardX = new float[] { -142f, -47f, 47f, 142f };

        // Card 1: Gear 1 (5 Sun)
        CreateBuyCard(buyBar.transform, "Card_1", cardX[0], "card_small_teal", "Gear 1", "5", false, font);

        // Card 2: Gear 2 (10 Sun)
        CreateBuyCard(buyBar.transform, "Card_2", cardX[1], "card_small_teal", "Gear 2", "10", false, font);

        // Card 3: Gear 4 (Free with Ad)
        CreateBuyCard(buyBar.transform, "Card_3", cardX[2], "card_small_teal", "Gear 4", "Free", true, font);

        // Card 4: Empty
        CreateBuyCard(buyBar.transform, "Card_4", cardX[3], "card_small_teal", null, null, false, font);

        // Action Buttons Row
        // Refresh Button (Green)
        var btnRefresh = CreateRect("Btn_Refresh", buyBar.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-95, -75), new Vector2(110, 48));
        CreateImage("Refresh_Bg", btnRefresh.transform, GetSprite("button_big_green"), Vector2.zero, new Vector2(110, 48), preserveAspect: false);
        CreateText("Refresh_Title", btnRefresh.transform, "Refresh", new Vector2(0, 10), new Vector2(100, 16), 13, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        CreateImage("Refresh_Sun", btnRefresh.transform, GetSprite("icon_sun"), new Vector2(-12, -10), new Vector2(18, 18));
        CreateText("Refresh_Cost", btnRefresh.transform, "5", new Vector2(12, -10), new Vector2(30, 18), 14, Color.white, font, TextAnchor.MiddleLeft, FontStyle.Bold);

        // START! Button (Cyan)
        var btnStart = CreateRect("Btn_Start", buyBar.transform, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(65, -75), new Vector2(180, 48));
        CreateImage("Start_Bg", btnStart.transform, GetSprite("button_big_cyan"), Vector2.zero, new Vector2(180, 48), preserveAspect: false);
        CreateText("Start_Text", btnStart.transform, "START!", Vector2.zero, new Vector2(180, 44), 22, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
    }

    private static void CreateBuyCard(Transform parent, string name, float xPos, string cardBg, string gearSprite, string costText, bool isAdCard, Font font)
    {
        var card = CreateRect(name, parent, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(xPos, 25), new Vector2(86, 110));
        CreateImage("Card_Bg", card.transform, GetSprite(cardBg), Vector2.zero, new Vector2(86, 110), preserveAspect: false);

        if (!string.IsNullOrEmpty(gearSprite))
        {
            CreateImage("Gear_Img", card.transform, GetSprite(gearSprite), new Vector2(0, 10), new Vector2(50, 50));
        }

        if (isAdCard)
        {
            // Info badge 'i' (left)
            CreateImage("Badge_Info", card.transform, GetSprite("dot_cyan"), new Vector2(-28, 42), new Vector2(18, 18));
            CreateText("Info_Txt", card.transform, "i", new Vector2(-28, 42), new Vector2(18, 18), 12, Color.black, font, TextAnchor.MiddleCenter, FontStyle.Bold);

            // Ad play badge (right)
            CreateImage("Badge_Ad", card.transform, GetSprite("icon video ad"), new Vector2(28, 42), new Vector2(20, 18));
        }

        if (!string.IsNullOrEmpty(costText))
        {
            CreateImage("Pill_Bg", card.transform, GetSprite("tag_price"), new Vector2(0, -35), new Vector2(62, 22), preserveAspect: false);
            CreateImage("Pill_Sun", card.transform, GetSprite("icon_sun"), new Vector2(-16, -35), new Vector2(16, 16));
            CreateText("Pill_Cost", card.transform, costText, new Vector2(8, -35), new Vector2(36, 18), 12, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        }
    }

    private static void CreateToggleHUD(Transform canvasTransform, ScreenSwitcher switcher, Font font)
    {
        var hud = CreateRect("Screen_Switcher_HUD", canvasTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0, -2), new Vector2(400, 28));

        // Screen 1 Button
        var btn1 = CreateRect("Btn_Show_Screen1", hud.transform, new Vector2(0.25f, 0.5f), new Vector2(0.25f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(120, 22));
        var b1Img = CreateImage("Bg", btn1.transform, GetSprite("button_big_green"), Vector2.zero, new Vector2(120, 22), preserveAspect: false);
        CreateText("Txt", btn1.transform, "1: Main Game", Vector2.zero, new Vector2(120, 20), 10, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        var b1 = btn1.AddComponent<Button>();
        b1.targetGraphic = b1Img;
        UnityEditor.Events.UnityEventTools.AddPersistentListener(b1.onClick, switcher.ShowScreen1);

        // Screen 2 Button
        var btn2 = CreateRect("Btn_Show_Screen2", hud.transform, new Vector2(0.75f, 0.5f), new Vector2(0.75f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(120, 22));
        var b2Img = CreateImage("Bg", btn2.transform, GetSprite("button_big_cyan"), Vector2.zero, new Vector2(120, 22), preserveAspect: false);
        CreateText("Txt", btn2.transform, "2: Buy Gear", Vector2.zero, new Vector2(120, 20), 10, Color.white, font, TextAnchor.MiddleCenter, FontStyle.Bold);
        var b2 = btn2.AddComponent<Button>();
        b2.targetGraphic = b2Img;
        UnityEditor.Events.UnityEventTools.AddPersistentListener(b2.onClick, switcher.ShowScreen2);
    }

    // --- Helpers ---
    private static Sprite GetSprite(string name)
    {
        string path = "Assets/UI/" + name + ".png";
        var sp = AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (sp == null)
        {
            Debug.LogWarning("[InGameUIBuilder] Sprite not found at: " + path);
        }
        return sp;
    }

    private static GameObject CreateRect(string name, Transform parent, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 anchoredPos, Vector2 sizeDelta)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        var rt = go.AddComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.pivot = pivot;
        rt.anchoredPosition = anchoredPos;
        rt.sizeDelta = sizeDelta;
        return go;
    }

    private static Image CreateImage(string name, Transform parent, Sprite sprite, Vector2 pos, Vector2 size, Color? color = null, bool preserveAspect = true)
    {
        var go = CreateRect(name, parent, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), pos, size);
        var img = go.AddComponent<Image>();
        img.sprite = sprite;
        img.color = color ?? Color.white;
        img.preserveAspect = preserveAspect;
        return img;
    }

    private static Text CreateText(string name, Transform parent, string text, Vector2 pos, Vector2 size, int fontSize, Color color, Font font, TextAnchor alignment = TextAnchor.MiddleCenter, FontStyle style = FontStyle.Normal)
    {
        var go = CreateRect(name, parent, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), pos, size);
        var txt = go.AddComponent<Text>();
        txt.text = text;
        txt.fontSize = fontSize;
        txt.color = color;
        txt.alignment = alignment;
        txt.fontStyle = style;
        txt.font = font;
        return txt;
    }
}
